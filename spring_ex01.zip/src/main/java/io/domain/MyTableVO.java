package io.domain;

import lombok.Data;

@Data
public class MyTableVO {

    private int num;
    private  String memberName;
    private  String memberPw;


}
