package io.domain;

import lombok.Data;

@Data
public class MemberVO {

    public String name;
    public String pw;

}
